import random
for i = 0 to 100
    
